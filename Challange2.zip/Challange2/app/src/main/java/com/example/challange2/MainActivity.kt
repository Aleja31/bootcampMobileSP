package com.example.challange2
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView
import android.widget.Toast
import kotlin.random.Random


class MainActivity : AppCompatActivity(){

    //Define variables for the elements from the widget
    var mybutton : Button?= null
    var diceImage : ImageView?= null
    //Create the list of Images
    val listOfDice = arrayOf(R.drawable.dice_1, R.drawable.dice_2, R.drawable.dice_3,
        R.drawable.dice_4,R.drawable.dice_5,R.drawable.dice_6)


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Get the objects from the widget
        mybutton = findViewById(R.id.buttonRoll)
        diceImage = findViewById(R.id.diceImage)
        Toast.makeText(this,"Press ROLL to start the game", Toast.LENGTH_LONG).show()
        mybutton!!.setOnClickListener {diceImage!!.setImageResource(chooseDice())}
    }

    //Create the function to choose the random number of the dice
    fun chooseDice() : Int{
        val faceDice = Random.nextInt(0,6)
        println("VALOOOOR"+faceDice)
        return listOfDice[faceDice]

    }
}
